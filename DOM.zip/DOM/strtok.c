#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#define STR_SIZE 256

int main(void){
    FILE *inputFile = NULL;
    char inputFileName[STR_SIZE];
    scanf("%s", &inputFileName);
    inputFile = fopen(inputFileName, "r");
    int lineCount = 1;
    if(inputFile != NULL){
        char buffer[STR_SIZE];
        while(!feof(inputFile)){
            fgets(buffer,sizeof(buffer), inputFile);
            printf("%d번째 라인\n", lineCount++);
            char *ptr = strtok(buffer," ");

            while(ptr != NULL) {
                printf("단어 : %s\n",ptr);
                ptr = strtok(NULL, " ");
            }
        }
        fclose(inputFile);
    }else {
        printf("파일 x\n");
        return 0;
    }
    return 0;
}