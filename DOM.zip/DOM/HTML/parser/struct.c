#include <stdio.h>
struct person
{
    char *name;
    int age;
    struct phone
    {
        char *home_num;
        char *mobile_num;
    }number;
};
int main(void)
{
    struct person man={"jaeho", 18, {"02-345-0084", "019-945-0001"}};
    struct phone gal={"010-1234-1234","010-1231-1231"};
    printf("name : %s\n", man.name);
    printf("age : %d\n", man.age);
    printf("home : %s\n", man.number.home_num);
    printf("mobile : %s\n", man.number.mobile_num);
    printf("mobile2 : %s\n", gal.mobile_num);
    return 0;
}
