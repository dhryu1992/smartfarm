#include <stdio.h>           // printf 함수, gets_s 함수를 사용하기 위해!
#include <string.h>          // strlen 함수를 사용하기 위해!
#include <malloc.h>          // malloc 함수, free 함수를 사용하기 위해!
#include <stdlib.h>
#define MAX_LENGTH     1025   // 최대 128자까지만 입력 받는다.

int main()
{   
    char buffer[MAX_LENGTH] = {0, };
    FILE *fp = fopen("test.html","r");
    char *pt1, *pt2;
    char temp[MAX_LENGTH];
    char *index;
    char *context = (char*)malloc(sizeof(char)*MAX_LENGTH);
    *context = 0;
    while((feof(fp)) == 0)
    {   
        fread(&buffer,sizeof(char),1,fp);
        if(feof(fp)==0)
            strcat(context,buffer);
    }
    // printf("%s",context);
    pt1=strstr(context, "<");
    // printf(pt1);
    pt2=strstr(&pt1[1],">");
    index = (char*)malloc(MAX_LENGTH*sizeof(char));
    // printf(pt2);
    while(1)
        {   
            pt1=strstr(pt1, "<");
            pt2=strstr(&pt1[1],">");
            memcpy(index, ++pt1, pt2 - pt1);
            index[pt2 - pt1] = 0;
            // strcpy(element, temp);
            printf("%s\n",index);
            // printf("%s\n",temp);
            pt1 = &pt2[0];
            pt2++;
            if(*pt2 == 0)
                break;
        }
    free(context);
    free(index);
    fclose(fp);
    return 0;    
}