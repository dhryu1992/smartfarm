#include <stdio.h>           // printf 함수, gets_s 함수를 사용하기 위해!
#include <string.h>          // strlen 함수를 사용하기 위해!
#include <malloc.h>          // malloc 함수, free 함수를 사용하기 위해!
#include <stdlib.h>
#define MAX_LENGTH     1025   // 최대 128자까지만 입력 받는다.

int main()
{   
    char buffer[MAX_LENGTH] = {0, };
    FILE *fp = fopen("test.html","r");
    char *pt1, *pt2;
    char temp[MAX_LENGTH];
    int length;
    char *index;
    int i = 0;

    while(feof(fp) == 0)
    {   
        fread(buffer,sizeof(char)*1024,1,fp);
        // printf("1\n");
        // printf("%s", buffer);
        // pt1=strstr(buffer, "<");
        // pt2=strstr(&pt1[1],">");
        pt1=strstr(buffer, "<");
        // printf(pt1);
        pt2=strstr(&pt1[1],">");
        index = (char*)malloc(MAX_LENGTH*sizeof(char));
        
        while(1)
        {
            // printf("2\n");
            pt1=strstr(pt1, "<");
            // printf(pt1);
            pt2=strstr(&pt1[1],">");
            memcpy(index, ++pt1, pt2 - pt1);
            index[pt2 - pt1] = 0;
            // strcpy(element, temp);
            printf("%s\n",index);
            // printf("%s\n",temp);
            pt1 = &pt2[0];
            pt2++;
            if(*pt2 == 0)
                break;
            i++;
            free(index);
        }
        memset(buffer, 0, 9);
    }
        fclose(fp);
    return 0;    
        // printf("4\n");
}