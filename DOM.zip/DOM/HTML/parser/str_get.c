#include <stdio.h>           // printf 함수, gets_s 함수를 사용하기 위해!
#include <string.h>          // strlen 함수를 사용하기 위해!
#include <malloc.h>          // malloc 함수, free 함수를 사용하기 위해!
#include <stdlib.h>
#define MAX_LENGTH     128   // 최대 128자까지만 입력 받는다.

int main()
{
    char *str = "<!DOCTYPE html> \
                <html lang=""> \
                <head>\
                    <title>\
                        Document\
                    </title>\
                </head>\
                <body>\
                    HTML, Image<br>\
                    abc\
                    <!-- 내용. 내용 -->\
                </body>\
                </html>";
    char *pt1, *pt2, temp[256];
   
        pt1=strstr(str, "<");
        pt2=strstr(&pt1[1],">");
        if (pt1==NULL || pt2==NULL)
            printf("\n Invalid string %s", str);
        else {
            for(int i = 0; i<10; i++){
            pt1=strstr(&pt1[0], "<");
            pt2=strstr(&pt1[1],">");
            // printf("%s\n",pt1);
            memcpy(temp, ++pt1, pt2 - pt1);
            temp[pt2 - pt1] = 0;
            printf("%s\n",temp);
            pt1 = &pt2[2];
            // printf("%s\n",pt1);
            pt2++;
        }
    
    }
return 0;
}