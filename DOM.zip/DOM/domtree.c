
struct _doc{
    struct html Html;
}doc;

struct html{
    struct head Head;
    struct body Body;
}

struct head{
    struct meta Meta;
    struct title Title;
}

struct title{
    char T[100];
}

struct body{
    struct image Image;
    char *content[10];
}

struct image{
    char src[10];
    char alt[10];
    int width;
    int height;
}

text = "abced";

printf(text);


struct element{
    tagname = img
    attribute[0] src
    value[0] pict
}

<body>
    내용
    <img src="pic_trulli.jpg" alt="Trulli" width="500" height="333">
</body>


tagname=strtok(" ")
for
    attrbute[n]=strtok(=)
    value[n]=strtok(" ")
    n+=1
value[n] = strtok(>)

text
image

element 1
element 2