
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
//문자열에서 문자 제거
#include <string.h>
//#include <stdlib.h>
#include <stdio.h> 
 
void Eliminate(char *str, char ch);
int main(void)
{
    char source[256] = "";
    printf("입력 문자열:");
    gets_s(source, sizeof(source));
 
    printf("제거할 문자:");<br>    char temp[256] = "";
    scanf_s("%s", temp, sizeof(temp));
    char ch = temp[0]; 
 
    Eliminate(source, '<p>');
    printf("%s\n", source);
    return 0;
}
 
void Eliminate(char *str, char ch)
{
    unsigned len = strlen(str) + 1;
    for (; *str != '\0'; str++,len--)//종료 문자를 만날 때까지 반복
    {
        if (*str == ch)//ch와 같은 문자일 때
        {
            strcpy_s(str,len, str + 1);
            str--;            
        }
    }
}